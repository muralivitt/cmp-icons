package com.muralivitt.cmp.icons.vuesax.bold

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

import kotlin.Suppress

val VuesaxIconsBold.ElementEqual: ImageVector
    get() {
        if (_ElementEqual != null) {
            return _ElementEqual!!
        }
        _ElementEqual = ImageVector.Builder(
            name = "ElementEqual",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(21f, 16.25f)
                horizontalLineTo(15f)
                curveTo(14.59f, 16.25f, 14.25f, 15.91f, 14.25f, 15.5f)
                curveTo(14.25f, 15.09f, 14.59f, 14.75f, 15f, 14.75f)
                horizontalLineTo(21f)
                curveTo(21.41f, 14.75f, 21.75f, 15.09f, 21.75f, 15.5f)
                curveTo(21.75f, 15.91f, 21.41f, 16.25f, 21f, 16.25f)
                close()
            }
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(21f, 20.25f)
                horizontalLineTo(15f)
                curveTo(14.59f, 20.25f, 14.25f, 19.91f, 14.25f, 19.5f)
                curveTo(14.25f, 19.09f, 14.59f, 18.75f, 15f, 18.75f)
                horizontalLineTo(21f)
                curveTo(21.41f, 18.75f, 21.75f, 19.09f, 21.75f, 19.5f)
                curveTo(21.75f, 19.91f, 21.41f, 20.25f, 21f, 20.25f)
                close()
            }
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(22f, 8.52f)
                verticalLineTo(3.98f)
                curveTo(22f, 2.57f, 21.36f, 2f, 19.77f, 2f)
                horizontalLineTo(15.73f)
                curveTo(14.14f, 2f, 13.5f, 2.57f, 13.5f, 3.98f)
                verticalLineTo(8.51f)
                curveTo(13.5f, 9.93f, 14.14f, 10.49f, 15.73f, 10.49f)
                horizontalLineTo(19.77f)
                curveTo(21.36f, 10.5f, 22f, 9.93f, 22f, 8.52f)
                close()
            }
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(10.5f, 8.52f)
                verticalLineTo(3.98f)
                curveTo(10.5f, 2.57f, 9.86f, 2f, 8.27f, 2f)
                horizontalLineTo(4.23f)
                curveTo(2.64f, 2f, 2f, 2.57f, 2f, 3.98f)
                verticalLineTo(8.51f)
                curveTo(2f, 9.93f, 2.64f, 10.49f, 4.23f, 10.49f)
                horizontalLineTo(8.27f)
                curveTo(9.86f, 10.5f, 10.5f, 9.93f, 10.5f, 8.52f)
                close()
            }
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(10.5f, 19.77f)
                verticalLineTo(15.73f)
                curveTo(10.5f, 14.14f, 9.86f, 13.5f, 8.27f, 13.5f)
                horizontalLineTo(4.23f)
                curveTo(2.64f, 13.5f, 2f, 14.14f, 2f, 15.73f)
                verticalLineTo(19.77f)
                curveTo(2f, 21.36f, 2.64f, 22f, 4.23f, 22f)
                horizontalLineTo(8.27f)
                curveTo(9.86f, 22f, 10.5f, 21.36f, 10.5f, 19.77f)
                close()
            }
        }.build()

        return _ElementEqual!!
    }

@Suppress("ObjectPropertyName")
private var _ElementEqual: ImageVector? = null
