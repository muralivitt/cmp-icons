package com.muralivitt.cmp.icons.vuesax.bold

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

import kotlin.Suppress

val VuesaxIconsBold.LocationMinus: ImageVector
    get() {
        if (_LocationMinus != null) {
            return _LocationMinus!!
        }
        _LocationMinus = ImageVector.Builder(
            name = "LocationMinus",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(20.619f, 8.7f)
                curveTo(19.579f, 4.07f, 15.539f, 2f, 11.999f, 2f)
                curveTo(11.999f, 2f, 11.999f, 2f, 11.989f, 2f)
                curveTo(8.459f, 2f, 4.429f, 4.07f, 3.379f, 8.69f)
                curveTo(2.199f, 13.85f, 5.359f, 18.22f, 8.219f, 20.98f)
                curveTo(9.279f, 22f, 10.639f, 22.51f, 11.999f, 22.51f)
                curveTo(13.359f, 22.51f, 14.719f, 22f, 15.769f, 20.98f)
                curveTo(18.629f, 18.22f, 21.789f, 13.86f, 20.619f, 8.7f)
                close()
                moveTo(14.749f, 11.75f)
                horizontalLineTo(9.249f)
                curveTo(8.839f, 11.75f, 8.499f, 11.41f, 8.499f, 11f)
                curveTo(8.499f, 10.59f, 8.839f, 10.25f, 9.249f, 10.25f)
                horizontalLineTo(14.749f)
                curveTo(15.159f, 10.25f, 15.499f, 10.59f, 15.499f, 11f)
                curveTo(15.499f, 11.41f, 15.159f, 11.75f, 14.749f, 11.75f)
                close()
            }
        }.build()

        return _LocationMinus!!
    }

@Suppress("ObjectPropertyName")
private var _LocationMinus: ImageVector? = null
