package com.muralivitt.cmp.icons.vuesax.bold

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

import kotlin.Suppress

val VuesaxIconsBold.Frame: ImageVector
    get() {
        if (_Frame != null) {
            return _Frame!!
        }
        _Frame = ImageVector.Builder(
            name = "Frame",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(12f, 2f)
                curveTo(9.38f, 2f, 7.25f, 4.13f, 7.25f, 6.75f)
                curveTo(7.25f, 9.32f, 9.26f, 11.4f, 11.88f, 11.49f)
                curveTo(11.96f, 11.48f, 12.04f, 11.48f, 12.1f, 11.49f)
                curveTo(12.12f, 11.49f, 12.13f, 11.49f, 12.15f, 11.49f)
                curveTo(12.16f, 11.49f, 12.16f, 11.49f, 12.17f, 11.49f)
                curveTo(14.73f, 11.4f, 16.74f, 9.32f, 16.75f, 6.75f)
                curveTo(16.75f, 4.13f, 14.62f, 2f, 12f, 2f)
                close()
            }
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(17.081f, 14.149f)
                curveTo(14.291f, 12.289f, 9.741f, 12.289f, 6.931f, 14.149f)
                curveTo(5.661f, 14.999f, 4.961f, 16.149f, 4.961f, 17.379f)
                curveTo(4.961f, 18.609f, 5.661f, 19.749f, 6.921f, 20.589f)
                curveTo(8.321f, 21.529f, 10.161f, 21.999f, 12.001f, 21.999f)
                curveTo(13.841f, 21.999f, 15.681f, 21.529f, 17.081f, 20.589f)
                curveTo(18.341f, 19.739f, 19.041f, 18.599f, 19.041f, 17.359f)
                curveTo(19.031f, 16.129f, 18.341f, 14.989f, 17.081f, 14.149f)
                close()
            }
        }.build()

        return _Frame!!
    }

@Suppress("ObjectPropertyName")
private var _Frame: ImageVector? = null
