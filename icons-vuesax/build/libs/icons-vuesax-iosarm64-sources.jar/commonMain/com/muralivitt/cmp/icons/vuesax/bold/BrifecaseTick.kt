package com.muralivitt.cmp.icons.vuesax.bold

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

import kotlin.Suppress

val VuesaxIconsBold.BrifecaseTick: ImageVector
    get() {
        if (_BrifecaseTick != null) {
            return _BrifecaseTick!!
        }
        _BrifecaseTick = ImageVector.Builder(
            name = "BrifecaseTick",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(21.091f, 6.98f)
                curveTo(20.241f, 6.04f, 18.831f, 5.57f, 16.761f, 5.57f)
                horizontalLineTo(16.521f)
                verticalLineTo(5.53f)
                curveTo(16.521f, 3.85f, 16.521f, 1.77f, 12.761f, 1.77f)
                horizontalLineTo(11.241f)
                curveTo(7.481f, 1.77f, 7.481f, 3.85f, 7.481f, 5.53f)
                verticalLineTo(5.57f)
                horizontalLineTo(7.241f)
                curveTo(5.171f, 5.57f, 3.751f, 6.04f, 2.911f, 6.98f)
                curveTo(1.921f, 8.09f, 1.951f, 9.56f, 2.051f, 10.569f)
                lineTo(2.061f, 10.639f)
                lineTo(2.13f, 11.446f)
                curveTo(2.143f, 11.599f, 2.227f, 11.739f, 2.357f, 11.823f)
                curveTo(2.64f, 12.006f, 2.942f, 12.199f, 3.231f, 12.359f)
                curveTo(3.371f, 12.45f, 3.521f, 12.53f, 3.671f, 12.609f)
                curveTo(4.801f, 13.229f, 6.011f, 13.719f, 7.251f, 14.059f)
                curveTo(7.281f, 16.649f, 9.401f, 18.75f, 12.001f, 18.75f)
                curveTo(14.621f, 18.75f, 16.751f, 16.619f, 16.751f, 14f)
                verticalLineTo(13.96f)
                curveTo(18.011f, 13.58f, 19.221f, 13.05f, 20.351f, 12.389f)
                curveTo(20.411f, 12.359f, 20.451f, 12.33f, 20.501f, 12.3f)
                curveTo(20.896f, 12.085f, 21.305f, 11.804f, 21.679f, 11.54f)
                curveTo(21.795f, 11.457f, 21.87f, 11.328f, 21.885f, 11.187f)
                lineTo(21.951f, 10.58f)
                curveTo(21.961f, 10.519f, 21.961f, 10.469f, 21.971f, 10.399f)
                curveTo(22.051f, 9.4f, 22.031f, 8.02f, 21.091f, 6.98f)
                close()
                moveTo(8.911f, 5.53f)
                curveTo(8.911f, 3.83f, 8.911f, 3.19f, 11.241f, 3.19f)
                horizontalLineTo(12.761f)
                curveTo(15.091f, 3.19f, 15.091f, 3.83f, 15.091f, 5.53f)
                verticalLineTo(5.57f)
                horizontalLineTo(8.911f)
                verticalLineTo(5.53f)
                close()
                moveTo(12.001f, 17.25f)
                curveTo(10.351f, 17.25f, 8.981f, 16.01f, 8.781f, 14.41f)
                curveTo(8.761f, 14.28f, 8.751f, 14.139f, 8.751f, 14f)
                curveTo(8.751f, 12.21f, 10.211f, 10.75f, 12.001f, 10.75f)
                curveTo(13.791f, 10.75f, 15.251f, 12.21f, 15.251f, 14f)
                curveTo(15.251f, 14.12f, 15.241f, 14.229f, 15.231f, 14.34f)
                verticalLineTo(14.349f)
                curveTo(15.051f, 15.979f, 13.671f, 17.25f, 12.001f, 17.25f)
                close()
            }
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(11.429f, 16.028f)
                curveTo(11.239f, 16.028f, 11.049f, 15.958f, 10.899f, 15.808f)
                lineTo(9.909f, 14.828f)
                curveTo(9.619f, 14.538f, 9.619f, 14.058f, 9.909f, 13.768f)
                curveTo(10.199f, 13.478f, 10.679f, 13.478f, 10.969f, 13.768f)
                lineTo(11.449f, 14.248f)
                lineTo(13.059f, 12.768f)
                curveTo(13.359f, 12.488f, 13.839f, 12.508f, 14.119f, 12.808f)
                curveTo(14.399f, 13.108f, 14.379f, 13.588f, 14.079f, 13.868f)
                lineTo(11.949f, 15.838f)
                curveTo(11.789f, 15.958f, 11.609f, 16.028f, 11.429f, 16.028f)
                close()
            }
            path(fill = SolidColor(Color(0xFF292D32))) {
                moveTo(21.042f, 13.731f)
                curveTo(21.29f, 13.593f, 21.613f, 13.793f, 21.587f, 14.076f)
                lineTo(21.232f, 17.961f)
                curveTo(21.022f, 19.961f, 20.202f, 22.001f, 15.802f, 22.001f)
                horizontalLineTo(8.182f)
                curveTo(3.782f, 22.001f, 2.962f, 19.961f, 2.762f, 17.971f)
                lineTo(2.416f, 14.268f)
                curveTo(2.389f, 13.98f, 2.696f, 13.786f, 2.952f, 13.921f)
                curveTo(3.732f, 14.351f, 4.542f, 14.731f, 5.372f, 15.031f)
                curveTo(5.682f, 15.141f, 5.902f, 15.401f, 5.992f, 15.721f)
                curveTo(6.742f, 18.321f, 9.162f, 20.251f, 12.002f, 20.251f)
                curveTo(14.892f, 20.251f, 17.332f, 18.281f, 18.042f, 15.581f)
                curveTo(18.122f, 15.261f, 18.342f, 15.001f, 18.652f, 14.881f)
                curveTo(19.492f, 14.551f, 20.292f, 14.161f, 21.042f, 13.731f)
                close()
            }
        }.build()

        return _BrifecaseTick!!
    }

@Suppress("ObjectPropertyName")
private var _BrifecaseTick: ImageVector? = null
