package com.muralivitt.cmp.icons.tabler.filled

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val TablerIconFilled.CircleLetterN: ImageVector
    get() {
        if (_CircleLetterN != null) {
            return _CircleLetterN!!
        }
        _CircleLetterN = ImageVector.Builder(
            name = "CircleLetterN",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 2f)
                curveToRelative(5.523f, 0f, 10f, 4.477f, 10f, 10f)
                reflectiveCurveToRelative(-4.477f, 10f, -10f, 10f)
                reflectiveCurveToRelative(-10f, -4.477f, -10f, -10f)
                reflectiveCurveToRelative(4.477f, -10f, 10f, -10f)
                moveToRelative(-1.106f, 5.553f)
                curveToRelative(-0.471f, -0.944f, -1.894f, -0.608f, -1.894f, 0.447f)
                verticalLineToRelative(8f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = false, 1f, 1f)
                lineToRelative(0.117f, -0.007f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = false, 0.883f, -0.993f)
                verticalLineToRelative(-3.764f)
                lineToRelative(2.106f, 4.211f)
                curveToRelative(0.471f, 0.944f, 1.894f, 0.608f, 1.894f, -0.447f)
                verticalLineToRelative(-8f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = false, -1f, -1f)
                lineToRelative(-0.117f, 0.007f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = false, -0.883f, 0.993f)
                verticalLineToRelative(3.764f)
                close()
            }
        }.build()

        return _CircleLetterN!!
    }

@Suppress("ObjectPropertyName")
private var _CircleLetterN: ImageVector? = null
